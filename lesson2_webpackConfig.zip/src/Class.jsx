
class Developer {
    constructor(name){
        this.name = name;
    }
    sayHi(){
        alert(`${this.name} говорит привет!`);
    }
}

export default Developer;
