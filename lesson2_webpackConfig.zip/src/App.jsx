import React, {Component} from 'react';

import './style.css';
import './Class.jsx';

class App extends Component {
    render() {
        return (
            <h1>Hello React!</h1>
        );
    }
}

export default App;
